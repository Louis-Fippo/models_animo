<?php
$name = "Story Verified Badge";
$supported_version = "2.0+";
$author = "Rehan Adil";
$author_url = "http://themephysics.com";