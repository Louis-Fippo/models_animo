<?php
function urlpreview_search_launchericon()
{
	return '<span class="option" onclick="toggleMediaGroup(\'.urlpreview-search-wrapper\');">
        <i class="icon-music"></i>
    </span>';
}
\SocialKit\Addons::register('new_story_feature_launchericon', 'urlpreview_search_launchericon');
