<?php
require_once('head_tags.php');
require_once('launcher.php');
require_once('container.php');
require_once('insert.php');
require_once('display.php');
require_once('search.php');
