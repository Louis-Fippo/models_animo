<?php
activate_plugin('MediaElementJs');

require_once('head_tags.php');
require_once('launcher.php');
require_once('container.php');
require_once('upload.php');
require_once('display.php');
require_once('call.php');
