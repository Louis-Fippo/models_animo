<?php
userOnly();

include('requests/announcements/' . $a . '.php');