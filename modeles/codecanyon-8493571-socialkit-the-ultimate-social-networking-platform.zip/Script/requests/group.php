<?php
userOnly();

include('requests/group/' . $a . '.php');