<?php
include('requests/user/' . $a . '.php');