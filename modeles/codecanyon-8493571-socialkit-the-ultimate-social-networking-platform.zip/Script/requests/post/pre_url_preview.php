<?php
if (isset($_POST['text']))
{
	$text = $_POST['text'];
	
	$text = $escapeObj->createLinks($text);
    $text = $escapeObj->createHashtags($text);
    $text = $escapeObj->postEscape($text);

    $text = $escapeObj->getLinks($text);
    
    $previewHtml = "";

    $rgx1 = '/\<a href\=\"(|https:\/\/|http:\/\/)(|www\.)youtube.com\/watch\?v\=([a-zA-Z0-9_-]+)(|\&feature\=youtu\.be)\"(.*?)\<\/a\>/i';
	if (preg_match_all($rgx1, $text, $matches))
	{
		foreach ($matches[0] as $k => $match)
		{
			$yid = $matches[3][$k];
			$previewHtml = '<iframe width="100%" height="315" src="https://www.youtube.com/embed/' . $yid . '" frameborder="0" allowfullscreen></iframe>';
		}
	}

	$rgx2 = '/\<a href\=\"(|https:\/\/|http:\/\/)(|www\.)youtu.be\/([a-zA-Z0-9_-]+)\"(.*?)\<\/a\>/i';
	if (preg_match_all($rgx2, $text, $matches))
	{
		foreach ($matches[0] as $k => $match)
		{
			$yid = $matches[3][$k];
			$previewHtml = '<iframe width="100%" height="315" src="https://www.youtube.com/embed/' . $yid . '" frameborder="0" allowfullscreen></iframe>';
		}
	}

	$rgx3 = '/\<a href\=\"(|https:\/\/|http:\/\/)(|www\.)youtube.com\/(embed|v)\/([a-zA-Z0-9_-]+)\"(.*?)\<\/a\>/i';
	if (preg_match_all($rgx3, $text, $matches))
	{
		foreach ($matches[0] as $k => $match)
		{
			$yid = $matches[4][$k];
			$previewHtml = '<iframe width="100%" height="315" src="https://www.youtube.com/embed/' . $yid . '" frameborder="0" allowfullscreen></iframe>';
		}
	}

	$rgx4 = '/\<a href\=\"(|https:\/\/|http:\/\/)(|www\.)(.*?)\"(.*?)rel\=\"nofollow\"(.*?)\<\/a\>/i';
	if (preg_match_all($rgx4, $text, $matches))
	{
		foreach ($matches[0] as $k => $match)
		{
			$url = $matches[1][$k] . $matches[2][$k] . $matches[3][$k];

			$headers = @get_headers($url);

			if (strpos($headers[0],'200') == true)
			{
				$urlname = preg_replace('/[^A-Za-z0-9_]/i', '', $url);
				$metadir = 'meta_tags/' . date('Y') . '/' . date('m');
				$metafile = $metadir . '/' . $urlname . '.json';
				if (! file_exists($metadir) )
				{
					mkdir($metadir, 0777, true);
				}

				if ( file_exists($metafile) )
				{
					$meta_data = file_get_contents($metafile);
					$meta_tags = json_decode($meta_data, true);
				}
				else
				{
					$escapeObj = new \SocialKit\Escape();
					$get_meta_tags = grab_meta_tags($url);
					$meta_tags = array();
					$meta_tags['title'] = $escapeObj->stringEscape($get_meta_tags['title']);
					
					if ( isset($get_meta_tags['img_preview']) )
					{
						$meta_tags['img_preview'] = $get_meta_tags['img_preview'];
						
						if (preg_match('/(\.jpg|\.png|\.gif)$/i', $meta_tags['img_preview']))
						{
							$ext = file_ext($meta_tags['img_preview']);
							$imgfile = $metadir . '/' . $urlname . '.' . $ext;
						}
						else
						{
							$imgfile = $metadir . '/' . $urlname . '.png';
						}
						
						file_put_contents($imgfile, file_get_contents($meta_tags['img_preview']));
						$meta_tags['img_preview'] = $imgfile;
					}

					if ( isset($get_meta_tags['description']) )
					{
						$meta_tags['description'] = $escapeObj->stringEscape($get_meta_tags['description']);
					}

					file_put_contents($metafile, json_encode($meta_tags));
				}

				$previewHtml = '<div class="url-preview-container">';

				if (! empty($meta_tags['img_preview']) )
				{
					$previewHtml .= '<a href="' . $url . '" target="_blank">
						<div class="img-preview">
							<div style="background-image: url(\'' . $config['site_url'] .'/' . $meta_tags['img_preview'] .'\');"></div>
						</div>
					</a>';
				}
				else {
					$previewHtml .= '<a href="' . $url . '" target="_blank">
						<div class="img-preview">
							<div style="background-image: url(\'' . $config['site_url'] .'/addons/add.StoryURLPreview/defaultbg.jpg\');"></div>
						</div>
					</a>';
				}

				if (! empty($meta_tags['title']) )
				{
					$previewHtml .= '<div class="title">
						<a href="' . $url . '" target="_blank">' . $meta_tags['title'] . '</a>
					</div>';
				}

				if (! empty($meta_tags['description']) )
				{
					$previewHtml .= '<div class="descr">
						<a href="' . $url . '" target="_blank">' . $meta_tags['description'] . '</a>
					</div>';
				}

				$previewHtml .= '</div>';
			}
		}
	}

	if (! empty($previewHtml))
	{
		$data = array(
		    'status' => 200,
		    'html' => $previewHtml
		);
	}
}

header("Content-type: application/json; charset=utf-8");
echo json_encode($data);
$conn->close();
exit();