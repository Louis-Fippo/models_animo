<?php
userOnly();

include('requests/album/' . $a . '.php');