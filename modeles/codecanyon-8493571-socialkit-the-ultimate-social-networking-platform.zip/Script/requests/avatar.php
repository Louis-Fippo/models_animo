<?php
userOnly();

include('requests/avatar/' . $a . '.php');