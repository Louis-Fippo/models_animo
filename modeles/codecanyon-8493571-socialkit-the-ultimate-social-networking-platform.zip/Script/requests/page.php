<?php
userOnly();

include('requests/page/' . $a . '.php');