<?php
userOnly();

$searchQuery = $escapeObj->stringEscape($_GET['query']);
$data = array();

foreach ($userObj->getFollowers($searchQuery) as $k => $v) {
    $followerObj = new \SocialKit\User();
    $followerObj->setId($v);
    $follower = $followerObj->getRows();

    $data[] = array(
    	"id" => $follower['id'],
    	"username" => $follower['username'],
    	"name" => $follower['name'],
    	"avatar" => $follower['thumbnail_url'],
    	"type" => "contact"
    );

    
}

header("Content-type: application/json; charset=utf-8");
echo json_encode($data);
$conn->close();
exit();