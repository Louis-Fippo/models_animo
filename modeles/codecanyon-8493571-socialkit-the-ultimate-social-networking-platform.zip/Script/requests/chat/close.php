<?php
unset($_SESSION['chat_recipient_id']);
$conn->close();
exit();