<?php
userOnly();

include('requests/cover/' . $a . '.php');