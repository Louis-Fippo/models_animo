<?php
userOnly();

include('requests/event/' . $a . '.php');