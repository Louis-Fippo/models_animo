<?php
userOnly();

include('requests/events/' . $a . '.php');