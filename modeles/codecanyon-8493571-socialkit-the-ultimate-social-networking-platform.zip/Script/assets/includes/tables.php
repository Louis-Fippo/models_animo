<?php

define('DB_ACCOUNTS', 'accounts');
define('DB_ANNOUNCEMENTS', 'announcements');
define('DB_ANNOUNCEMENT_VIEWS', 'announcement_views');
define('DB_BLOCKERS', 'blocks');
define('DB_CONFIGURATIONS', 'configurations');
define('DB_FOLLOWERS', 'followers');
define('DB_GROUPS', 'groups');
define('DB_GROUP_ADMINS', 'group_admins');
define('DB_HASHTAGS', 'hashtags');
define('DB_MEDIA', 'media');
define('DB_NOTIFICATIONS', 'notifications');
define('DB_PAGES', 'pages');
define('DB_PAGE_ADMINS', 'page_admins');
define('DB_PAGE_CATEGORIES', 'page_categories');
define('DB_POSTS', 'posts');
define('DB_POSTLIKES', 'postlikes');
define('DB_POSTSHARES', 'postshares');
define('DB_POSTFOLLOWS', 'postfollows');
define('DB_COMMENTS', 'comments');
define('DB_COMMENTLIKES', 'commentlikes');
define('DB_MESSAGES', 'messages');
define('DB_REPORTS', 'reports');
define('DB_USERS', 'users');
define('DB_LANGUAGES', 'languages');
define('DB_EVENTS', 'events');
define('DB_EVENT_INVITES', 'event_invites');