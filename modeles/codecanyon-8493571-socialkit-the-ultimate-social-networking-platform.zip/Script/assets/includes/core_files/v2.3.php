<?php

function getEventBar() {
    global $themeData;
    $themeData['new_event'] = smoothLink('index.php?tab1=create_event');
    $themeData['list_events'] = getEvents();
    return \SocialKit\UI::view('event-bar/content');
}

function getEvents() {
	if (!isLogged()) return null;

	global $conn, $themeData, $user, $lang;
	$currentTime = time();
    $listEvents = '';

	$queryText = "SELECT id,location,start_time,end_time FROM " . DB_EVENTS . " WHERE end_time>$currentTime AND id IN (SELECT id FROM " . DB_ACCOUNTS . " WHERE active=1) ORDER BY start_time LIMIT 3";
	$query = $conn->query($queryText);

	while ($fetch = $query->fetch_array(MYSQLI_ASSOC))
	{
		$eventObj = new \SocialKit\User();
        $eventObj->setId($fetch['id']);
        $event = $eventObj->getRows();

        $location = $fetch['location'];
        $startTime = $fetch['start_time'];
        $endTime = $fetch['end_time'];
        $eventTime = date('l h:i A', $startTime) . ' - ' . date('h:i A', $endTime);

        $themeData['list_event_id'] = $event['id'];
        $themeData['list_event_url'] = $event['url'];
        $themeData['list_event_username'] = $event['username'];
        $themeData['list_event_name'] = $event['name'];
        $themeData['list_event_thumbnail_url'] = $event['cover_url'];

        $themeData['list_event_location'] = $location;

        $inviteQuery = $conn->query("SELECT action FROM " . DB_EVENT_INVITES . " WHERE event_id=" . $fetch['id'] . " AND timeline_id=" . $user['id'] . " AND active=1");
        if ($inviteQuery->num_rows == 1)
        {
            $inviteFetch = $inviteQuery->fetch_array(MYSQLI_ASSOC);
            $inviteType = $inviteFetch['action'];
        }

        switch ($inviteType) {
            case 'going':
                $themeData['event_status_icon'] = 'check-circle';
                $themeData['event_status'] = $lang['event_going_label'];
                break;

            case 'interested':
                $themeData['event_status_icon'] = 'star';
                $themeData['event_status'] = $lang['event_interested_label'];
                break;

            case 'invited':
                $themeData['event_status_icon'] = 'inbox';
                $themeData['event_status'] = $lang['event_invited_label'];
                break;
            
            default:
                $themeData['event_status_icon'] = 'circle-o';
                $themeData['event_status'] = $lang['event_notgoing_label'];
                break;
        }

        $oneHour = 60 * 60;
        $threeDays = 60 * 60 * 24 * 3;
        $oneWeek = 60 * 60 * 24 * 7;

        if ($startTime < $currentTime)
        {
        	$eventTime = 'Happening Now';
        }
        elseif (($currentTime + $oneHour) > $startTime)
        {
            $minsRemaining = round(($startTime - $currentTime) / 60);
            $eventTime = str_replace("{minCount}", $minsRemaining, $lang['event_in_minutes_label']);
        }
        elseif (($currentTime + $threeDays) > $startTime)
        {
            $hoursRemaining = ceil((($startTime - $currentTime) / 60) / 60);
            $eventTime = str_replace("{hrsCount}", $hoursRemaining, $lang['event_in_hours_label']);
        }
        elseif (($currentTime + $oneWeek) > $startTime)
        {
            $eventTime = date('l h:i A', $startTime);
        }
        else
        {
            $eventTime = str_replace("{eventTime}", date('M j h:i A', $startTime), $lang['on_event_time_label']);
        }

        $themeData['list_event_time'] = $eventTime;
        
        $listEvents .= \SocialKit\UI::view('event-bar/each');
	}

	return $listEvents;
}

function getEventInvitesData($searchQuery='', $eventId = 0, $limit=5)
{
    if (! isLogged())
    {
        return array();
    }
    
    $eventId = (int) $eventId;
    $limit = (int) $limit;
    $get = array();
    
    if ($limit < 1)
    {
        $limit = 5;
    }
    
    global $conn, $user;
    
    $queryText = "SELECT id FROM " . DB_ACCOUNTS . "
    WHERE id IN (SELECT following_id FROM " . DB_FOLLOWERS . " WHERE follower_id=" . $user['id'] . ")
    AND id NOT IN (SELECT timeline_id FROM " . DB_EVENT_INVITES . " WHERE event_id=$eventId AND active=1)
    AND id<>" . $user['id'] . " AND active=1";

    if (! empty($searchQuery))
    {
        $escapeObj = new \SocialKit\Escape();
        $searchQuery = $escapeObj->stringEscape($searchQuery);
        $queryText .= " AND name LIKE '%$searchQuery%'";
    }
    
    $queryText .= " ORDER BY RAND() LIMIT $limit";
    $query = $conn->query($queryText);

    while ($fetch = $query->fetch_array(MYSQLI_ASSOC))
    {
        $get[] = $fetch['id'];
    }

    return $get;
}

function getEventInviteList($searchQuery='', $eventId = 0, $limit=5)
{
    global $lang;

    if (! isLogged())
    {
        return array();
    }
    
    global $themeData;
    $invitesHtml = '';

    foreach (getEventInvitesData($searchQuery, $eventId, $limit) as $k => $v)
    {
        $timelineObj = new \SocialKit\User();
        $timelineObj->setId($v);
        $timeline = $timelineObj->getRows();
        
        $themeData['list_invite_id'] = $timeline['id'];
        $themeData['list_invite_url'] = $timeline['url'];
        $themeData['list_invite_username'] = $timeline['username'];
        $themeData['list_invite_name'] = $timeline['name'];
        $themeData['list_invite_thumbnail_url'] = $timeline['thumbnail_url'];

        $invitesHtml .= \SocialKit\UI::view('timeline/event/list-invite-each');
    }

    if (!empty($invitesHtml))
    {
        return $invitesHtml;
    }
}

function isEventInvited($eventId = 0, $timelineId = 0, $action = 'all')
{
    $eventId = (int) $eventId;
    $timelineId = (int) $timelineId;
    if ($eventId < 1)
    {
        return false;
    }

    $queryText = "SELECT id,action FROM " . DB_EVENT_INVITES . " WHERE event_id=$eventId";
    if ($timelineId > 0)
    {
        $queryText .= " AND timeline_id=$timelineId";
    }

    switch ($action) {
        case 'going':
            $queryText .= " AND action='going'";
            break;

        case 'interested':
            $queryText .= " AND action='interested'";
            break;

        case 'invited':
            $queryText .= " AND action='invited'";
            break;
        
        default:
            $queryText .= "";
            break;
    }

    $queryText .= " AND active=1";

    global $conn;
    $query = $conn->query($queryText);
    
    if (preg_match('/(going|interested|invited)/i', $action))
    {
        return $query->num_rows;
    }
    elseif ($query->num_rows == 1)
    {
        $fetch = $query->fetch_array(MYSQLI_ASSOC);
        return $fetch['action'];
    }
}

function updateEventAction($eventId = 0, $timelineId = 0, $action = 'all')
{
    $eventId = (int) $eventId;
    $timelineId = (int) $timelineId;
    if ($eventId < 1)
    {
        return false;
    }
    if ($timelineId < 1)
    {
        return false;
    }

    if (! preg_match('/(going|interested|invited)/', $action))
    {
        return false;
    }

    $checkQuery = "SELECT id,action FROM " . DB_EVENT_INVITES . " WHERE event_id=$eventId AND timeline_id=$timelineId";
    
    global $conn;
    $check = $conn->query($checkQuery);
    
    if ($check->num_rows > 0)
    {
        $queryText = "UPDATE " . DB_EVENT_INVITES . " SET action='$action' WHERE event_id=$eventId AND timeline_id=$timelineId";
    }
    else
    {
        $queryText = "INSERT INTO " . DB_EVENT_INVITES . " (action,active,event_id,timeline_id) VALUES ('$action',1,'$eventId','$timelineId')";
    }

    $query = $conn->query($queryText);

    if ($query)
    {
        return true;
    }
}