<?php
/* Facebook Client */
define ('FACEBOOK_APP_ID', '786589321399444');
define ('FACEBOOK_APP_SECRET', '118744cfac92c49562c8d3914ccec898');
define ('FACEBOOK_APP_REDIRECT_URI', $config['site_url'] . '/social-login/facebook');


/* Google Client */
define ('GOOGLE_CLIENT_ID', '325292103146-m3vseridprraoeb0aqugfafs37qlanun.apps.googleusercontent.com');
define ('GOOGLE_CLIENT_SECRET', 'xtUk_gPSZ1171Hj9gSkIDrMV');
define ('GOOGLE_REDIRECT_URI', $config['site_url'] . '/social-login/google');


/* Twitter Client */
define ('TWITTER_CONSUMER_KEY', 'j8ucplstEgPz3mj6nWa5NKU4p');
define ('TWITTER_CONSUMER_SECRET', 'P3Dw13WXVQOial6AHrAomREck8XWVWrALkEA1GYduZolyVlZau');
define ('TWITTER_REDIRECT_URI', $config['site_url'] . '/social-login/twitter');


/* Instagram Client */
define ('INSTAGRAM_CLIENT_ID', '57239e1bcbe046ab82555f6c2bca3cb9');
define ('INSTAGRAM_CLIENT_SECRET', 'a58f18319d7a40fa887151ee841e40c8');
define ('INSTAGRAM_REDIRECT_URI', $config['site_url'] . '/social-login/instagram');