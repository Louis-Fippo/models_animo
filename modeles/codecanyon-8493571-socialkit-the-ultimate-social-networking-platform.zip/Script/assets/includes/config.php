<?php

// MySQL Hostname / Server (for eg: 'localhost')
$sql_host = 'DB_HOST';


// MySQL Database Name
$sql_name = 'DB_NAME';


// MySQL Database User
$sql_user = 'DB_USER';


// MySQL Database Password
$sql_pass = 'DB_PASSWORD';


// Site URL
$site_url = 'http://YOUR-SITE.com'; // You must write "http://", or "https://" if you have SSL
