<?php
$themeData['footer_tags'] = "";
$themeData['footer_tags'] .= ($PLUGINS['Mentions'] == true) ? '<script src="' . $site_url . '/3rd_plugins/Mentions/elastic.js" ></script>
<script src="' . $site_url . '/3rd_plugins/Mentions/jquery.mentionsInput.js"></script>
<script>
$("textarea.story-text-area").mentionsInput({
  onDataRequest:function (mode, query, callback) {
    $.get(reqSource(), {t: "search", a: "mentions", query: query}, function(data) {
        data = _.filter(data, function(item) { return item.name.toLowerCase().indexOf(query.toLowerCase()) > -1 });
        callback.call(this, data);
    });
  }
});
</script>' : "";

$themeData['footer_tags'] .= \SocialKit\Addons::invoke(array('footer_tags_add_content', 'string'));