<?php
if (isset($_POST['import_keywords']) && isset($_POST['keep_blank']) && empty($_POST['keep_blank']) && $logged_in == true)
{
    $saved = false;
    $sklFile = 'lang_' . time() . '.skl';

    if (isset ($_FILES['lang_import_file']['tmp_name']))
    {
        $file = $_FILES['lang_import_file'];
        $name = preg_replace('/([^A-Za-z0-9_\-\.]+)/i', '', $file['name']);
        $ext = strtolower(substr($file['name'], strrpos($file['name'], '.') + 1, strlen($file['name']) - strrpos($file['name'], '.')));
        
        if ($file['size'] > 0)
        {
            if ($ext == "skl")
            {
                if (move_uploaded_file($file['tmp_name'], $sklFile))
                {
                    $importData = file_get_contents($sklFile);
                    $importArray = json_decode($importData, true);

                    $ltQuery = mysqli_query($dbConnect, "SELECT DISTINCT type FROM " . DB_LANGUAGES);

                    while ($ltFetch = mysqli_fetch_assoc($ltQuery))
                    {
                        $lt = $ltFetch['type'];

                        foreach ($importArray as $key => $value)
                        {
                            $lkQuery = mysqli_query($dbConnect, "SELECT id FROM " . DB_LANGUAGES . " WHERE type='$lt' AND keyword='$key'");

                            if (mysqli_num_rows($lkQuery) == 0)
                            {
                                mysqli_query($dbConnect, "INSERT INTO " . DB_LANGUAGES . " (type,keyword,text) VALUES ('$lt', '$key', '$value')");
                            }
                        }
                    }

                    unlink($sklFile);
                    $saved = true;
                    mysqli_query($dbConnect , "UPDATE " . DB_CONFIGURATIONS . " SET reset_time=" . time());
                }
            }
        }
    }
    
    if ($saved == true)
    {
        $post_message = '<div class="post-success">Keywords have been imported.</div>';
    }
    else
    {
        $post_message = '<div class="post-failure">Something went wrong! Please try again.</div>';
    }
}
