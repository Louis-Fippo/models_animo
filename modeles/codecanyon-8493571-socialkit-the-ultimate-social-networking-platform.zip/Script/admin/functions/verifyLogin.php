<?php
function SK_verifyLogin()
{
    global $dbConnect;

    require('../assets/includes/config.php');
    $config = array();
    $confQuery = mysqli_query($dbConnect, "SELECT * FROM " . DB_CONFIGURATIONS);
    $config = mysqli_fetch_assoc($confQuery);

    $config['site_url'] = $site_url;
    $config['theme_url'] = $site_url . '/themes/' . $config['theme'];

    $config = array();
    $confQuery = mysqli_query($dbConnect, "SELECT * FROM " . DB_CONFIGURATIONS);
    $config = mysqli_fetch_assoc($confQuery);
    
    if (! empty($_SESSION['admin_id']) && ! empty($_SESSION['admin_password']))
    {
        if ($_SESSION['admin_id'] == $config['admin_username'] && $_SESSION['admin_password'] == $config['admin_password'])
        {
            return true;
        }
    }
}
