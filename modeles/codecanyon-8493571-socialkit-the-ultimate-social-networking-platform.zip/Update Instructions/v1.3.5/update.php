<?php
// Includes
require('assets/includes/config.php');
require('assets/includes/tables.php');

// Connect to SQL Server
$conn = new mysqli($sql_host, $sql_user, $sql_pass, $sql_name);

// Check connection
if ($conn->connect_errno)
{
    exit($conn->connect_errno);
}

$get_query = $conn->query("SELECT * FROM " . DB_POSTSHARES);

while ($fetch_query = $get_query->fetch_array(MYSQLI_ASSOC))
{
	// id, active, post_id, time, timeline_id, timestamp
	$conn->query("INSERT INTO " . DB_POSTS . " (active,post_id,shared,time,timeline_id) VALUES (1," . $fetch_query['post_id'] . ",1," . time() . "," . $fetch_query['timeline_id'] . ")");
}

echo "<h1>Done! Now please delete this file immediately.</h1>";