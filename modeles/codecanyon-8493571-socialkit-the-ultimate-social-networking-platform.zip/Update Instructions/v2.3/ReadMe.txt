This Update Instruction is for users who are using v2.2. If you've purchased the script after August 25, you can skip this update.

Minimum PHP version required is 5.4. Before installing the update, please make sure your PHP version is atleast 5.4.


To install the update, please follow these steps in order:

1 - Import the "import.sql" in your database.

2 - Backup all files and folders in your server into a zip file and download the zip.

3 - Configure your website and MySQL details in "Script/assets/includes/config.php".

4 - Configure your Social Login (FB, Google, Twitter, Instagram) details in "Script/assets/includes/social_config.php".

5 - Copy all files and folders from "Script" folder into your server.

6 - Go to Admin Panel -> Languages -> Import Keywords, and import the "language.skl" file.

7 - Done! Cheers :D


Enjoy!