CREATE TABLE `events` ( `id` INT(255) NOT NULL AUTO_INCREMENT , `end_time` INT(12) NOT NULL , `location` VARCHAR(255) NOT NULL , `private` INT(1) NOT NULL DEFAULT '0' , `start_time` INT(12) NOT NULL , `timeline_id` INT(255) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;
ALTER TABLE `accounts` CHANGE `type` `type` ENUM('user','page','group','event') CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL;

CREATE TABLE `event_invites` ( `id` INT(255) NOT NULL AUTO_INCREMENT , `action` ENUM('going','interested','invited') NOT NULL , `active` INT(1) NOT NULL , `event_id` INT(255) NOT NULL , `timeline_id` INT(255) NOT NULL , PRIMARY KEY (`id`)) ENGINE = InnoDB;

