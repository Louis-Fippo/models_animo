This Update Instruction is for users who are using v2.1. If you've purchased the script after June 16, you can skip this update.

Minimum PHP version required is 5.4. Before installing the update, please make sure your PHP version is atleast 5.4.


To install the update, please follow these steps in order:

1 - Import the "import.sql" in your database.

2 - Backup all files and folders in your server into a zip file and download the zip.

3 - Configure your website and MySQL details in "Script/assets/includes/config.php"

4 - Copy all files and folders from "Script" folder into your server.

5 - Go to Admin Panel -> Languages -> Import Keywords, and import the "language.skl" file.

6 - Done! Cheers :D


Enjoy!