This Update Instruction is for users who are using from v1.2. This is a minor bug fix update. If you've downloaded the Script after 28th October, you can skip this update. To install update, please follow these steps in order:

1. Copy the "connect.php" file and replace it in your server where the Script is installed (usually public_html) inside "assets/includes" folder.

2. Copy the "core.php" file and replace it in your server where the Script is installed (usually public_html) inside "assets/includes" folder.

3. Copy the "user.phtml" file and replace it in your server where the Script is installed (usually public_html) inside "themes/grape/layout/timeline" folder.

4. Copy the "process.php" file and replace it in your server where the Script is installed (usually public_html) inside "themes/grape/emoticons" folder.

5. Copy the "settings.phtml" file and replace it in your server where the Script is installed (usually public_html) inside "themes/grape/layout/user" folder.

6. Copy the "content.phtml" file and replace it in your server where the Script is installed (usually public_html) inside "themes/grape/layout/home" folder.

7. Copy the "update_site_settings.php" file and replace it in your server where the Script is installed (usually public_html) inside "admin/requests" folder.