This Update Instruction is for users who are using v1.3.3. If you've downloaded the script after April 16th, you can skip this update.

Minimum PHP version required is 5.4. Before installing the update, please make sure your PHP version is atleast 5.4.


To install the update, please follow these steps in order:

1 - Import the "import.sql" in your database.

2 - Copy and replace the files listed in "change.log" from the Script folder into your server, OR just upload all files from the Script folder into your server and configure "config.php" with your database and website details.

3. It's done!


Thank you!