This Update Instruction is for users who are upgrading from v1.1.

If you're upgrading from v1.0, please follow the Update Instruction to v1.1 first.

If you are installing this for the first time, please follow the Documentation instead. To install update, please follow these steps in order:


1. Import "Update.SQL" in your current database's MySQL phpMyadmin.

2. Follow the documentation except don't import "SocialKit.SQL" in your current database's MySQL phpMyadmin.


Admin panel settings and login details will be reset once the update is complete, please take a look at the Documentation for the default admin username and password.


Contact me at themarvelkit@gmail.com if you need help with update.