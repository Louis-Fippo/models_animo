This Update Instruction is for users who are using v1.2.2. This is a minor bug fix update. If you've downloaded the Script after November 10th, you can skip this update. To install update, please follow these steps in order:

1. Copy "request.php" and replace it in your server where the Script is installed (usually public_html).

2. Copy the files in "includes" folder and replace them in your server where the Script is installed (usually public_html) inside "assets/includes" folder.

3. Copy the files in "javascript" folder and replace them in your server where the Script is installed (usually public_html) inside "themes/grape/javascript" folder.

4. Copy the files in "languages" folder and replace them in your server where the Script is installed (usually public_html) inside "assets/languages" folder.

5. Copy the files in "sources" folder and replace them in your server where the Script is installed (usually public_html) inside "assets/sources" folder.

6. Copy the files in "layout/header" folder and replace them in your server where the Script is installed (usually public_html) inside "themes/grape/layout/header" folder.

7. Copy the files in "layout/home" folder and replace them in your server where the Script is installed (usually public_html) inside "themes/grape/layout/home" folder.

8. Copy the files in "layout/story-page" folder and replace them in your server where the Script is installed (usually public_html) inside "themes/grape/layout/story-page" folder.

9. Copy the files in "layout/timeline" folder and replace them in your server where the Script is installed (usually public_html) inside "themes/grape/layout/timeline" folder.