This Update Instruction is for users who are using v1.3.6. If you've downloaded the script after September 11, you can skip this update.

Minimum PHP version required is 5.4. Before installing the update, please make sure your PHP version is atleast 5.4.


To install the update, please follow these steps in order:

1 - Open "guide.html" in your browser and copy and replace the files mentioned from the Script folder into your server.

3. You're done!


Thank you!