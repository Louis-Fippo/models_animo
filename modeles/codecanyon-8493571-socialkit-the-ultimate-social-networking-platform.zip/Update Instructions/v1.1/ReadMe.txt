This Update Instruction is for users who are upgrading from v1.0. If you are installing this for the first time, please follow the Documentation instead. To install update, please follow these steps in order:


1. Import "Update.SQL" in your current database's MySQL phpMyadmin.

2. Follow the documentation except don't import "SocialKit.SQL" in your current database's MySQL phpMyadmin.

3. Copy "hashfix.php" in your website's root directory and open it in URL. For example, http://yoursite.com/hashfix.php

4. Once done, delete the file "hashfix.php".


Contact me at themarvelkit@gmail.com if you need help with update.