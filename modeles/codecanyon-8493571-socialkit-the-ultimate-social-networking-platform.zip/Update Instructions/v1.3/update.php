<?php
// Includes
require('assets/includes/config.php');
require('assets/includes/tables.php');

// Connect to SQL Server
$conn = new mysqli($sql_host, $sql_user, $sql_pass, $sql_name);

// Check connection
if ($conn->connect_errno)
{
    exit($conn->connect_errno);
}

$settings_files = glob('assets/settings/*.php');
$config = array();

foreach ($settings_files as $sets_file)
{
	include($sets_file);
}

$mushfiq = $config;
ksort($mushfiq);

$ks = array();
$vs = array();

foreach ($mushfiq as $k => $v)
{
	$ks[] = $k;

	if (is_numeric($v) or is_bool($v))
	{
		$vs[] = (int) $v;
	}
	else
	{
		$vs[] = "'" . $v . "'";
	}
}

$ksq = implode(',', $ks);
$vsq = implode(',', $vs);

$conn->query("DELETE FROM " . DB_CONFIGURATIONS);

$conquery = "INSERT INTO " . DB_CONFIGURATIONS . " ($ksq) VALUES ($vsq);";
$conn->query($conquery);

echo "<h1>Done!";