This Update Instruction is for users who are using v1.2.3. If you've downloaded the Script after April 2nd, you can skip this update.

Minimum PHP version required is 5.4. Before installing the update, please make sure your PHP version is atleast 5.4.

If you need, you can contact me providing your FTP & phpMyadmin access using the following form: http://codecanyon.net/user/ThemePhysics#contact and I will install the update for you.

If you're using any third party plugins, they might stop working after installing the update, so please contact the respective authors of the plugins and ask them to update their plugins for the latest version.

The theme system has changed a lot, if you've made any customization to the theme except the css and javascript files, you will most probably need to do them again using the new theme syntaxes.


To install the update, please follow these steps in order:

1 - [IMPORTANT!] In your server, create a backup of all files in "assets/settings" folder, and download the backup.

2 - Using phpMyadmin, import the "import.SQL" file in the related database.

3 - Delete all files and folders except "photos" from the server and upload all files and folders from the Script folder into your server.

4 - Configure database and website details in "assets/includes/config.php" file in your server.

5 - Upload all files from the backup from Step #1 to "assets/settings" folder in your server.

6 - Upload the file "update.php" in your server.

7 - In your browser, open YOUR_SITE.COM/update.php. For example, if your website URL is www.mysocialnetwork.com, then you should open "www.mysocialnetwork.com/update.php".

8 - Once done, delete the update.php file from the server and you're done!


If you need, you can contact me providing your FTP & phpMyadmin access using the following form: http://codecanyon.net/user/ThemePhysics#contact and I will install the update for you.

Thank you!