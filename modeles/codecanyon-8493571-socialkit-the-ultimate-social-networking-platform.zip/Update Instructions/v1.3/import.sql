-- phpMyAdmin SQL Dump
-- version 4.1.6
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2015 at 10:32 AM
-- Server version: 5.6.16
-- PHP Version: 5.5.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `socialkit`
--

-- --------------------------------------------------------

--
-- Table structure for table `plugins`
--

CREATE TABLE IF NOT EXISTS `plugins` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `active` int(1) NOT NULL DEFAULT '0',
  `folder` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=1 ;

CREATE TABLE IF NOT EXISTS `configurations` (
  `ad_place_hashtag` text NOT NULL,
  `ad_place_home` text NOT NULL,
  `ad_place_messages` text NOT NULL,
  `ad_place_search` text NOT NULL,
  `ad_place_timeline` text NOT NULL,
  `admin_password` varchar(255) NOT NULL DEFAULT 'e9aada4fd797d65069187d7a961691cc',
  `admin_username` varchar(255) NOT NULL DEFAULT 'marvelkit',
  `captcha` int(1) NOT NULL DEFAULT '0',
  `censored_words` varchar(255) NOT NULL DEFAULT 'racist,retard',
  `chat` int(1) NOT NULL DEFAULT '0',
  `comment_character_limit` int(255) NOT NULL DEFAULT '0',
  `email` varchar(255) NOT NULL DEFAULT 'no-reply@website.com',
  `email_verification` int(1) NOT NULL DEFAULT '0',
  `friends` int(1) NOT NULL DEFAULT '0',
  `language` varchar(255) NOT NULL DEFAULT 'english',
  `message_character_limit` int(255) NOT NULL DEFAULT '0',
  `reg_req_about` int(1) NOT NULL DEFAULT '0',
  `reg_req_birthday` int(1) NOT NULL DEFAULT '0',
  `reg_req_currentcity` int(1) NOT NULL DEFAULT '0',
  `reg_req_hometown` int(1) NOT NULL DEFAULT '0',
  `site_name` varchar(255) NOT NULL DEFAULT 'Site Name',
  `site_title` varchar(255) NOT NULL DEFAULT 'Site Title',
  `smooth_links` int(1) NOT NULL DEFAULT '0',
  `story_character_limit` int(255) NOT NULL DEFAULT '0',
  `theme` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

UPDATE page_categories SET name='pcat_local_business_or_place' WHERE id=1;
UPDATE page_categories SET name='pcat_airport' WHERE id=2;
UPDATE page_categories SET name='pcat_arts_entertainment_nightlife' WHERE id=3;
UPDATE page_categories SET name='pcat_attractions_things_to_do' WHERE id=4;
UPDATE page_categories SET name='pcat_automotive' WHERE id=5;
UPDATE page_categories SET name='pcat_bank_financial_services' WHERE id=6;
UPDATE page_categories SET name='pcat_bar' WHERE id=7;
UPDATE page_categories SET name='pcat_book_store' WHERE id=8;
UPDATE page_categories SET name='pcat_business_services' WHERE id=9;
UPDATE page_categories SET name='pcat_church_religious_organization' WHERE id=10;
UPDATE page_categories SET name='pcat_club' WHERE id=11;
UPDATE page_categories SET name='pcat_community_government' WHERE id=12;
UPDATE page_categories SET name='pcat_concert_venue' WHERE id=13;
UPDATE page_categories SET name='pcat_doctor' WHERE id=14;
UPDATE page_categories SET name='pcat_education' WHERE id=15;
UPDATE page_categories SET name='pcat_event_planning_event_services' WHERE id=16;
UPDATE page_categories SET name='pcat_food_grocery' WHERE id=17;
UPDATE page_categories SET name='pcat_health_medical_pharmacy' WHERE id=18;
UPDATE page_categories SET name='pcat_home_improvement' WHERE id=19;
UPDATE page_categories SET name='pcat_hospital_clinic' WHERE id=20;
UPDATE page_categories SET name='pcat_hotel' WHERE id=21;
UPDATE page_categories SET name='pcat_landmark' WHERE id=22;
UPDATE page_categories SET name='pcat_lawyer' WHERE id=23;
UPDATE page_categories SET name='pcat_library' WHERE id=24;
UPDATE page_categories SET name='pcat_local_business' WHERE id=25;
UPDATE page_categories SET name='pcat_middle_school' WHERE id=26;
UPDATE page_categories SET name='pcat_movie_theater' WHERE id=27;
UPDATE page_categories SET name='pcat_museum_art_gallery' WHERE id=28;
UPDATE page_categories SET name='pcat_outdoor_gear_sporting_goods' WHERE id=29;
UPDATE page_categories SET name='pcat_pet_services' WHERE id=30;
UPDATE page_categories SET name='pcat_professional_services' WHERE id=31;
UPDATE page_categories SET name='pcat_public_places' WHERE id=32;
UPDATE page_categories SET name='pcat_real_estate' WHERE id=33;
UPDATE page_categories SET name='pcat_restaurant_cafe' WHERE id=34;
UPDATE page_categories SET name='pcat_school' WHERE id=35;
UPDATE page_categories SET name='pcat_shopping_retail' WHERE id=36;
UPDATE page_categories SET name='pcat_spas_beauty_personal_care' WHERE id=37;
UPDATE page_categories SET name='pcat_sports_venue' WHERE id=38;
UPDATE page_categories SET name='pcat_sports_recreation_activities' WHERE id=39;
UPDATE page_categories SET name='pcat_tours_sightseeing' WHERE id=40;
UPDATE page_categories SET name='pcat_transportation' WHERE id=41;
UPDATE page_categories SET name='pcat_university' WHERE id=42;
UPDATE page_categories SET name='pcat_company__organization_or_institution' WHERE id=43;
UPDATE page_categories SET name='pcat_aerospace_defense' WHERE id=44;
UPDATE page_categories SET name='pcat_automobiles_and_parts' WHERE id=45;
UPDATE page_categories SET name='pcat_bank_financial_institution' WHERE id=46;
UPDATE page_categories SET name='pcat_biotechnology' WHERE id=47;
UPDATE page_categories SET name='pcat_cause' WHERE id=48;
UPDATE page_categories SET name='pcat_chemicals' WHERE id=49;
UPDATE page_categories SET name='pcat_church_religious_organization' WHERE id=50;
UPDATE page_categories SET name='pcat_community_organization' WHERE id=51;
UPDATE page_categories SET name='pcat_company' WHERE id=52;
UPDATE page_categories SET name='pcat_computers_technology' WHERE id=53;
UPDATE page_categories SET name='pcat_consulting_business_services' WHERE id=54;
UPDATE page_categories SET name='pcat_education' WHERE id=55;
UPDATE page_categories SET name='pcat_energy_utility' WHERE id=56;
UPDATE page_categories SET name='pcat_engineering_construction' WHERE id=57;
UPDATE page_categories SET name='pcat_farming_agriculture' WHERE id=58;
UPDATE page_categories SET name='pcat_food_beverages' WHERE id=59;
UPDATE page_categories SET name='pcat_government_organization' WHERE id=60;
UPDATE page_categories SET name='pcat_health_beauty' WHERE id=61;
UPDATE page_categories SET name='pcat_health_medical_pharmaceuticals' WHERE id=62;
UPDATE page_categories SET name='pcat_industrials' WHERE id=63;
UPDATE page_categories SET name='pcat_insurance_company' WHERE id=64;
UPDATE page_categories SET name='pcat_internet_software' WHERE id=65;
UPDATE page_categories SET name='pcat_legal_law' WHERE id=66;
UPDATE page_categories SET name='pcat_media_news_publishing' WHERE id=67;
UPDATE page_categories SET name='pcat_middle_school' WHERE id=68;
UPDATE page_categories SET name='pcat_mining_materials' WHERE id=69;
UPDATE page_categories SET name='pcat_non_governmental_organization__ngo_' WHERE id=70;
UPDATE page_categories SET name='pcat_non_profit_organization' WHERE id=71;
UPDATE page_categories SET name='pcat_organization' WHERE id=72;
UPDATE page_categories SET name='pcat_political_organization' WHERE id=73;
UPDATE page_categories SET name='pcat_political_party' WHERE id=74;
UPDATE page_categories SET name='pcat_retail_and_consumer_merchandise' WHERE id=75;
UPDATE page_categories SET name='pcat_school' WHERE id=76;
UPDATE page_categories SET name='pcat_small_business' WHERE id=77;
UPDATE page_categories SET name='pcat_telecommunication' WHERE id=78;
UPDATE page_categories SET name='pcat_transport_freight' WHERE id=79;
UPDATE page_categories SET name='pcat_travel_leisure' WHERE id=80;
UPDATE page_categories SET name='pcat_university' WHERE id=81;
UPDATE page_categories SET name='pcat_brand_or_product' WHERE id=82;
UPDATE page_categories SET name='pcat_appliances' WHERE id=83;
UPDATE page_categories SET name='pcat_baby_goods_kids_goods' WHERE id=84;
UPDATE page_categories SET name='pcat_bags_luggage' WHERE id=85;
UPDATE page_categories SET name='pcat_board_game' WHERE id=86;
UPDATE page_categories SET name='pcat_building_materials' WHERE id=87;
UPDATE page_categories SET name='pcat_camera_photo' WHERE id=88;
UPDATE page_categories SET name='pcat_cars' WHERE id=89;
UPDATE page_categories SET name='pcat_clothing' WHERE id=90;
UPDATE page_categories SET name='pcat_commercial_equipment' WHERE id=91;
UPDATE page_categories SET name='pcat_computers' WHERE id=92;
UPDATE page_categories SET name='pcat_drugs' WHERE id=93;
UPDATE page_categories SET name='pcat_electronics' WHERE id=94;
UPDATE page_categories SET name='pcat_food_beverages' WHERE id=95;
UPDATE page_categories SET name='pcat_furniture' WHERE id=96;
UPDATE page_categories SET name='pcat_games_toys' WHERE id=97;
UPDATE page_categories SET name='pcat_health_beauty' WHERE id=98;
UPDATE page_categories SET name='pcat_home_decor' WHERE id=99;
UPDATE page_categories SET name='pcat_household_supplies' WHERE id=100;
UPDATE page_categories SET name='pcat_jewelry_watches' WHERE id=101;
UPDATE page_categories SET name='pcat_kitchen_cooking' WHERE id=102;
UPDATE page_categories SET name='pcat_office_supplies' WHERE id=103;
UPDATE page_categories SET name='pcat_outdoor_gear_sporting_goods' WHERE id=104;
UPDATE page_categories SET name='pcat_patio_garden' WHERE id=105;
UPDATE page_categories SET name='pcat_pet_supplies' WHERE id=106;
UPDATE page_categories SET name='pcat_phone_tablet' WHERE id=107;
UPDATE page_categories SET name='pcat_product_service' WHERE id=108;
UPDATE page_categories SET name='pcat_software' WHERE id=109;
UPDATE page_categories SET name='pcat_tools_equipment' WHERE id=110;
UPDATE page_categories SET name='pcat_video_game' WHERE id=111;
UPDATE page_categories SET name='pcat_vitamins_supplements' WHERE id=112;
UPDATE page_categories SET name='pcat_website' WHERE id=113;
UPDATE page_categories SET name='pcat_wine_spirits' WHERE id=114;
UPDATE page_categories SET name='pcat_artist__band_or_public_figure' WHERE id=115;
UPDATE page_categories SET name='pcat_actor_director' WHERE id=116;
UPDATE page_categories SET name='pcat_artist' WHERE id=117;
UPDATE page_categories SET name='pcat_athlete' WHERE id=118;
UPDATE page_categories SET name='pcat_author' WHERE id=119;
UPDATE page_categories SET name='pcat_business_person' WHERE id=120;
UPDATE page_categories SET name='pcat_chef' WHERE id=121;
UPDATE page_categories SET name='pcat_coach' WHERE id=122;
UPDATE page_categories SET name='pcat_comedian' WHERE id=123;
UPDATE page_categories SET name='pcat_dancer' WHERE id=124;
UPDATE page_categories SET name='pcat_designer' WHERE id=125;
UPDATE page_categories SET name='pcat_entertainer' WHERE id=126;
UPDATE page_categories SET name='pcat_entrepreneur' WHERE id=127;
UPDATE page_categories SET name='pcat_fictional_character' WHERE id=128;
UPDATE page_categories SET name='pcat_government_official' WHERE id=129;
UPDATE page_categories SET name='pcat_journalist' WHERE id=130;
UPDATE page_categories SET name='pcat_movie_character' WHERE id=131;
UPDATE page_categories SET name='pcat_musician_band' WHERE id=132;
UPDATE page_categories SET name='pcat_news_personality' WHERE id=133;
UPDATE page_categories SET name='pcat_pet' WHERE id=134;
UPDATE page_categories SET name='pcat_photographer' WHERE id=135;
UPDATE page_categories SET name='pcat_politician' WHERE id=136;
UPDATE page_categories SET name='pcat_producer' WHERE id=137;
UPDATE page_categories SET name='pcat_public_figure' WHERE id=138;
UPDATE page_categories SET name='pcat_teacher' WHERE id=139;
UPDATE page_categories SET name='pcat_writer' WHERE id=140;
UPDATE page_categories SET name='pcat_entertainment' WHERE id=141;
UPDATE page_categories SET name='pcat_album' WHERE id=142;
UPDATE page_categories SET name='pcat_amateur_sports_team' WHERE id=143;
UPDATE page_categories SET name='pcat_book' WHERE id=144;
UPDATE page_categories SET name='pcat_book_series' WHERE id=145;
UPDATE page_categories SET name='pcat_book_store' WHERE id=146;
UPDATE page_categories SET name='pcat_concert_tour' WHERE id=147;
UPDATE page_categories SET name='pcat_concert_venue' WHERE id=148;
UPDATE page_categories SET name='pcat_fictional_character' WHERE id=149;
UPDATE page_categories SET name='pcat_library' WHERE id=150;
UPDATE page_categories SET name='pcat_magazine' WHERE id=151;
UPDATE page_categories SET name='pcat_movie' WHERE id=152;
UPDATE page_categories SET name='pcat_movie_character' WHERE id=153;
UPDATE page_categories SET name='pcat_movie_theater' WHERE id=154;
UPDATE page_categories SET name='pcat_music_award' WHERE id=155;
UPDATE page_categories SET name='pcat_music_chart' WHERE id=156;
UPDATE page_categories SET name='pcat_music_video' WHERE id=157;
UPDATE page_categories SET name='pcat_professional_sports_team' WHERE id=158;
UPDATE page_categories SET name='pcat_radio_station' WHERE id=159;
UPDATE page_categories SET name='pcat_record_label' WHERE id=160;
UPDATE page_categories SET name='pcat_school_sports_team' WHERE id=161;
UPDATE page_categories SET name='pcat_song' WHERE id=162;
UPDATE page_categories SET name='pcat_sports_league' WHERE id=163;
UPDATE page_categories SET name='pcat_sports_venue' WHERE id=164;
UPDATE page_categories SET name='pcat_studio' WHERE id=165;
UPDATE page_categories SET name='pcat_tv_channel' WHERE id=166;
UPDATE page_categories SET name='pcat_tv_network' WHERE id=167;
UPDATE page_categories SET name='pcat_tv_show' WHERE id=168;
UPDATE page_categories SET name='pcat_tv_movie_award' WHERE id=169;

ALTER TABLE `accounts` ADD INDEX( `avatar_id`, `cover_id`, `cover_position`, `email`, `name`, `password`, `time`, `timestamp`, `timezone`, `type`, `username`);
ALTER TABLE `accounts` ADD INDEX( `active`, `email_verification_key`, `email_verified`, `language`, `last_logged`, `verified`);
ALTER TABLE `configurations` ADD INDEX( `admin_password`, `admin_username`, `captcha`, `censored_words`, `chat`);
ALTER TABLE `configurations` ADD INDEX( `comment_character_limit`, `email`, `email_verification`, `friends`, `language`, `message_character_limit`);
ALTER TABLE `configurations` ADD INDEX( `reg_req_about`, `reg_req_birthday`, `reg_req_currentcity`, `reg_req_hometown`, `site_name`, `site_title`, `smooth_links`, `story_character_limit`, `theme`);
ALTER TABLE `posts` ADD INDEX( `active`, `hidden`, `link_title`, `link_url`, `media_id`, `post_id`, `recipient_id`, `soundcloud_title`);
ALTER TABLE `posts` ADD INDEX( `seen`, `time`, `timeline_id`, `timestamp`, `type1`, `type2`);
ALTER TABLE `users` ADD INDEX( `id`, `birthday`, `comment_privacy`, `confirm_followers`, `follow_privacy`, `gender`);
ALTER TABLE `users` ADD INDEX( `message_privacy`, `post_privacy`, `timeline_post_privacy`);
ALTER TABLE `media` ADD INDEX( `id`, `active`, `album_id`, `extension`, `post_id`, `temp`, `timeline_id`, `type`);
ALTER TABLE `page_admins` ADD INDEX( `id`, `active`, `admin_id`, `page_id`, `role`);
ALTER TABLE `group_admins` ADD INDEX( `id`, `active`, `admin_id`, `group_id`);
ALTER TABLE `pages` ADD INDEX( `id`, `category_id`, `message_privacy`, `phone`, `timeline_post_privacy`, `website`);
ALTER TABLE `groups` ADD INDEX( `id`, `add_privacy`, `group_privacy`, `timeline_post_privacy`);
ALTER TABLE `followers` ADD INDEX( `id`, `active`, `is_chatting`, `follower_id`, `following_id`, `time`, `timestamp`);

UPDATE `accounts` SET `avatar_id`=0,`cover_id`=0;

CREATE TABLE messages LIKE posts;
INSERT INTO messages SELECT * FROM posts;

DELETE FROM `messages` WHERE type1<>'messages';

ALTER TABLE `messages`
  DROP `activity_text`,
  DROP `google_map_name`,
  DROP `hidden`,
  DROP `link_title`,
  DROP `link_url`,
  DROP `post_id`,
  DROP `soundcloud_title`,
  DROP `soundcloud_uri`,
  DROP `type1`,
  DROP `type2`,
  DROP `youtube_video_id`,
  DROP `youtube_title`;

CREATE TABLE postlikes LIKE posts;
INSERT INTO postlikes SELECT * FROM posts;

DELETE FROM `postlikes` WHERE type1<>'story';
DELETE FROM `postlikes` WHERE type1='story' AND type2<>'like';

ALTER TABLE `postlikes`
  DROP `activity_text`,
  DROP `google_map_name`,
  DROP `hidden`,
  DROP `link_title`,
  DROP `link_url`,
  DROP `media_id`,
  DROP `recipient_id`,
  DROP `soundcloud_title`,
  DROP `soundcloud_uri`,
  DROP `seen`,
  DROP `text`,
  DROP `type1`,
  DROP `type2`,
  DROP `youtube_video_id`,
  DROP `youtube_title`;

CREATE TABLE postshares LIKE posts;
INSERT INTO postshares SELECT * FROM posts;

DELETE FROM `postshares` WHERE type1<>'story';
DELETE FROM `postshares` WHERE type1='story' AND type2<>'share';

ALTER TABLE `postshares`
  DROP `activity_text`,
  DROP `google_map_name`,
  DROP `hidden`,
  DROP `link_title`,
  DROP `link_url`,
  DROP `media_id`,
  DROP `recipient_id`,
  DROP `soundcloud_title`,
  DROP `soundcloud_uri`,
  DROP `seen`,
  DROP `text`,
  DROP `type1`,
  DROP `type2`,
  DROP `youtube_video_id`,
  DROP `youtube_title`;

CREATE TABLE postfollows LIKE posts;
INSERT INTO postfollows SELECT * FROM posts;

DELETE FROM `postfollows` WHERE type1<>'story';
DELETE FROM `postfollows` WHERE type1='story' AND type2<>'follow';

ALTER TABLE `postfollows`
  DROP `activity_text`,
  DROP `google_map_name`,
  DROP `hidden`,
  DROP `link_title`,
  DROP `link_url`,
  DROP `media_id`,
  DROP `recipient_id`,
  DROP `soundcloud_title`,
  DROP `soundcloud_uri`,
  DROP `seen`,
  DROP `text`,
  DROP `type1`,
  DROP `type2`,
  DROP `youtube_video_id`,
  DROP `youtube_title`;

CREATE TABLE commentlikes LIKE posts;
INSERT INTO commentlikes SELECT * FROM posts;

DELETE FROM `commentlikes` WHERE type1<>'comment';
DELETE FROM `commentlikes` WHERE type1='comment' AND type2<>'like';

ALTER TABLE `commentlikes`
  DROP `activity_text`,
  DROP `google_map_name`,
  DROP `hidden`,
  DROP `link_title`,
  DROP `link_url`,
  DROP `media_id`,
  DROP `recipient_id`,
  DROP `soundcloud_title`,
  DROP `soundcloud_uri`,
  DROP `seen`,
  DROP `text`,
  DROP `type1`,
  DROP `type2`,
  DROP `youtube_video_id`,
  DROP `youtube_title`;

CREATE TABLE comments LIKE posts;
INSERT INTO comments SELECT * FROM posts;

DELETE FROM `comments` WHERE type1<>'story';
DELETE FROM `comments` WHERE type1='story' AND type2<>'comment';

ALTER TABLE `comments`
  DROP `activity_text`,
  DROP `google_map_name`,
  DROP `hidden`,
  DROP `link_title`,
  DROP `link_url`,
  DROP `media_id`,
  DROP `recipient_id`,
  DROP `soundcloud_title`,
  DROP `soundcloud_uri`,
  DROP `seen`,
  DROP `type1`,
  DROP `type2`,
  DROP `youtube_video_id`,
  DROP `youtube_title`;

DELETE FROM `posts` WHERE type1<>'story';
DELETE FROM `posts` WHERE type1='story' AND type2<>'none';

ALTER TABLE `posts`
  DROP `type1`,
  DROP `type2`;

ALTER TABLE `accounts` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT, CHANGE `avatar_id` `avatar_id` INT(11) NOT NULL DEFAULT '0', CHANGE `cover_id` `cover_id` INT(11) NOT NULL DEFAULT '0', CHANGE `cover_position` `cover_position` INT(5) NOT NULL DEFAULT '0', CHANGE `email` `email` VARCHAR(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL, CHANGE `email_verification_key` `email_verification_key` VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL, CHANGE `language` `language` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL, CHANGE `last_logged` `last_logged` INT(12) NOT NULL, CHANGE `time` `time` INT(12) NOT NULL DEFAULT '0', CHANGE `timezone` `timezone` VARCHAR(80) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL, CHANGE `username` `username` VARCHAR(32) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL;
ALTER TABLE `announcements` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT, CHANGE `time` `time` INT(12) NOT NULL;
ALTER TABLE `announcement_views` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT, CHANGE `account_id` `account_id` INT(11) NULL, CHANGE `announcement_id` `announcement_id` INT(11) NOT NULL;
ALTER TABLE `commentlikes` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT, CHANGE `post_id` `post_id` INT(11) NOT NULL, CHANGE `time` `time` INT(12) NOT NULL, CHANGE `timeline_id` `timeline_id` INT(11) NOT NULL;
ALTER TABLE `comments` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT, CHANGE `post_id` `post_id` INT(11) NOT NULL, CHANGE `time` `time` INT(12) NOT NULL, CHANGE `timeline_id` `timeline_id` INT(11) NOT NULL;
ALTER TABLE `configurations` CHANGE `comment_character_limit` `comment_character_limit` INT(10) NOT NULL DEFAULT '0', CHANGE `email` `email` VARCHAR(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'no-reply@website.com', CHANGE `language` `language` VARCHAR(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'english', CHANGE `message_character_limit` `message_character_limit` INT(10) NOT NULL DEFAULT '0', CHANGE `site_name` `site_name` VARCHAR(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'Site Name', CHANGE `site_title` `site_title` VARCHAR(150) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT 'Site Title', CHANGE `story_character_limit` `story_character_limit` INT(10) NOT NULL DEFAULT '0', CHANGE `theme` `theme` VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '';
ALTER TABLE `followers` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT, CHANGE `follower_id` `follower_id` INT(11) NOT NULL, CHANGE `following_id` `following_id` INT(11) NOT NULL;
ALTER TABLE `groups` CHANGE `id` `id` INT(11) NOT NULL, CHANGE `add_privacy` `add_privacy` VARCHAR(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'members', CHANGE `group_privacy` `group_privacy` VARCHAR(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open', CHANGE `timeline_post_privacy` `timeline_post_privacy` VARCHAR(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'members';
ALTER TABLE `group_admins` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT, CHANGE `admin_id` `admin_id` INT(11) NOT NULL, CHANGE `group_id` `group_id` INT(11) NOT NULL;
ALTER TABLE `hashtags` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT, CHANGE `tag` `tag` VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL, CHANGE `last_trend_time` `last_trend_time` INT(12) NOT NULL, CHANGE `trend_use_num` `trend_use_num` INT(11) NOT NULL DEFAULT '0';
ALTER TABLE `media` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT, CHANGE `album_id` `album_id` INT(11) NOT NULL DEFAULT '0', CHANGE `post_id` `post_id` INT(11) NOT NULL, CHANGE `timeline_id` `timeline_id` INT(11) NOT NULL, CHANGE `type` `type` VARCHAR(10) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'none';
ALTER TABLE `messages` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT, CHANGE `media_id` `media_id` INT(11) NOT NULL DEFAULT '0', CHANGE `recipient_id` `recipient_id` INT(11) NOT NULL DEFAULT '0', CHANGE `seen` `seen` INT(12) NOT NULL DEFAULT '0', CHANGE `time` `time` INT(12) NOT NULL, CHANGE `timeline_id` `timeline_id` INT(11) NOT NULL;
ALTER TABLE `notifications` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT, CHANGE `notifier_id` `notifier_id` INT(11) NOT NULL, CHANGE `post_id` `post_id` INT(11) NOT NULL, CHANGE `seen` `seen` INT(12) NOT NULL, CHANGE `time` `time` INT(12) NOT NULL, CHANGE `timeline_id` `timeline_id` INT(11) NOT NULL, CHANGE `type` `type` VARCHAR(20) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'none';
ALTER TABLE `pages` CHANGE `id` `id` INT(11) NOT NULL, CHANGE `category_id` `category_id` INT(11) NOT NULL, CHANGE `message_privacy` `message_privacy` VARCHAR(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'everyone', CHANGE `phone` `phone` VARCHAR(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL, CHANGE `timeline_post_privacy` `timeline_post_privacy` VARCHAR(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'everyone';
ALTER TABLE `page_admins` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT, CHANGE `admin_id` `admin_id` INT(11) NOT NULL, CHANGE `page_id` `page_id` INT(11) NOT NULL, CHANGE `role` `role` VARCHAR(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL;
ALTER TABLE `page_categories` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT, CHANGE `category_id` `category_id` INT(11) NOT NULL;
ALTER TABLE `plugins` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT;
ALTER TABLE `postfollows` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT, CHANGE `post_id` `post_id` INT(11) NOT NULL DEFAULT '0', CHANGE `time` `time` INT(12) NOT NULL, CHANGE `timeline_id` `timeline_id` INT(11) NOT NULL;
ALTER TABLE `postlikes` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT, CHANGE `post_id` `post_id` INT(11) NOT NULL DEFAULT '0', CHANGE `time` `time` INT(12) NOT NULL, CHANGE `timeline_id` `timeline_id` INT(11) NOT NULL;
ALTER TABLE `posts` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT, CHANGE `media_id` `media_id` INT(11) NOT NULL DEFAULT '0', CHANGE `post_id` `post_id` INT(11) NOT NULL DEFAULT '0', CHANGE `recipient_id` `recipient_id` INT(11) NOT NULL DEFAULT '0', CHANGE `seen` `seen` INT(12) NOT NULL DEFAULT '0', CHANGE `time` `time` INT(12) NOT NULL, CHANGE `timeline_id` `timeline_id` INT(11) NOT NULL;
ALTER TABLE `postshares` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT, CHANGE `post_id` `post_id` INT(11) NOT NULL DEFAULT '0', CHANGE `time` `time` INT(12) NOT NULL, CHANGE `timeline_id` `timeline_id` INT(11) NOT NULL;
ALTER TABLE `reports` CHANGE `id` `id` INT(11) NOT NULL AUTO_INCREMENT, CHANGE `post_id` `post_id` INT(11) NOT NULL, CHANGE `reporter_id` `reporter_id` INT(11) NOT NULL;
ALTER TABLE `users` CHANGE `id` `id` INT(11) NOT NULL, CHANGE `comment_privacy` `comment_privacy` VARCHAR(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'everyone', CHANGE `confirm_followers` `confirm_followers` INT(1) NOT NULL DEFAULT '0', CHANGE `follow_privacy` `follow_privacy` VARCHAR(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'everyone', CHANGE `message_privacy` `message_privacy` VARCHAR(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'everyone', CHANGE `post_privacy` `post_privacy` VARCHAR(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'everyone', CHANGE `timeline_post_privacy` `timeline_post_privacy` VARCHAR(15) CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL DEFAULT 'everyone';

DROP TABLE blocks;

OPTIMIZE TABLE `accounts`, `announcements`, `announcement_views`, `blocks`, `commentlikes`, `comments`, `configurations`, `followers`, `groups`, `group_admins`, `hashtags`, `media`, `messages`, `notifications`, `pages`, `page_admins`, `page_categories`, `plugins`, `postfollows`, `postlikes`, `posts`, `postshares`, `reports`, `users`;