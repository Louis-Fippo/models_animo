-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Server version: 5.6.26
-- PHP Version: 5.6.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";

--
-- Database: `socialkit`
--

ALTER TABLE `posts` ADD `privacy` VARCHAR(10) NOT NULL DEFAULT 'public' AFTER `post_id`;
ALTER TABLE `postlikes` ADD `reaction` VARCHAR(8) NOT NULL DEFAULT 'like' AFTER `post_id`;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `type`, `keyword`, `text`) VALUES
(5185, 'deutsch', 'reaction_wow_label', 'Wow'),
(5186, 'english', 'reaction_wow_label', 'Wow'),
(5187, 'espanol', 'reaction_wow_label', 'Wow'),
(5188, 'icelandic', 'reaction_wow_label', 'Wow'),
(5189, 'indonesian', 'reaction_wow_label', 'Wow'),
(5190, 'jawa', 'reaction_wow_label', 'Wow'),
(5191, 'portuguese', 'reaction_wow_label', 'Wow'),
(5192, 'turkish', 'reaction_wow_label', 'Wow'),
(5193, 'deutsch', 'reaction_haha_label', 'Haha'),
(5194, 'english', 'reaction_haha_label', 'Haha'),
(5195, 'espanol', 'reaction_haha_label', 'Haha'),
(5196, 'icelandic', 'reaction_haha_label', 'Haha'),
(5197, 'indonesian', 'reaction_haha_label', 'Haha'),
(5198, 'jawa', 'reaction_haha_label', 'Haha'),
(5199, 'portuguese', 'reaction_haha_label', 'Haha'),
(5200, 'turkish', 'reaction_haha_label', 'Haha'),
(5201, 'deutsch', 'reaction_sad_label', 'Sad'),
(5202, 'english', 'reaction_sad_label', 'Sad'),
(5203, 'espanol', 'reaction_sad_label', 'Sad'),
(5204, 'icelandic', 'reaction_sad_label', 'Sad'),
(5205, 'indonesian', 'reaction_sad_label', 'Sad'),
(5206, 'jawa', 'reaction_sad_label', 'Sad'),
(5207, 'portuguese', 'reaction_sad_label', 'Sad'),
(5208, 'turkish', 'reaction_sad_label', 'Sad'),
(5209, 'deutsch', 'reaction_angry_label', 'Angry'),
(5210, 'english', 'reaction_angry_label', 'Angry'),
(5211, 'espanol', 'reaction_angry_label', 'Angry'),
(5212, 'icelandic', 'reaction_angry_label', 'Angry'),
(5213, 'indonesian', 'reaction_angry_label', 'Angry'),
(5214, 'jawa', 'reaction_angry_label', 'Angry'),
(5215, 'portuguese', 'reaction_angry_label', 'Angry'),
(5216, 'turkish', 'reaction_angry_label', 'Angry'),
(5217, 'deutsch', 'reaction_love_label', 'Love'),
(5218, 'english', 'reaction_love_label', 'Love'),
(5219, 'espanol', 'reaction_love_label', 'Love'),
(5220, 'icelandic', 'reaction_love_label', 'Love'),
(5221, 'indonesian', 'reaction_love_label', 'Love'),
(5222, 'jawa', 'reaction_love_label', 'Love'),
(5223, 'portuguese', 'reaction_love_label', 'Love'),
(5224, 'turkish', 'reaction_love_label', 'Love'),
(5225, 'deutsch', 'new_reaction_email_subject', '{user} has reacted to your post'),
(5226, 'english', 'new_reaction_email_subject', '{user} has reacted to your post'),
(5227, 'espanol', 'new_reaction_email_subject', '{user} has reacted to your post'),
(5228, 'icelandic', 'new_reaction_email_subject', '{user} has reacted to your post'),
(5229, 'indonesian', 'new_reaction_email_subject', '{user} has reacted to your post'),
(5230, 'jawa', 'new_reaction_email_subject', '{user} has reacted to your post'),
(5231, 'portuguese', 'new_reaction_email_subject', '{user} has reacted to your post'),
(5232, 'turkish', 'new_reaction_email_subject', '{user} has reacted to your post'),
(5233, 'deutsch', 'reacted_to_your_post', 'reacted to your post &quot;{post}...&quot;'),
(5234, 'english', 'reacted_to_your_post', 'reacted to your post &quot;{post}...&quot;'),
(5235, 'espanol', 'reacted_to_your_post', 'reacted to your post &quot;{post}...&quot;'),
(5236, 'icelandic', 'reacted_to_your_post', 'reacted to your post &quot;{post}...&quot;'),
(5237, 'indonesian', 'reacted_to_your_post', 'reacted to your post &quot;{post}...&quot;'),
(5238, 'jawa', 'reacted_to_your_post', 'reacted to your post &quot;{post}...&quot;'),
(5239, 'portuguese', 'reacted_to_your_post', 'reacted to your post &quot;{post}...&quot;'),
(5240, 'turkish', 'reacted_to_your_post', 'reacted to your post &quot;{post}...&quot;'),
(5241, 'deutsch', 'reactions_label', 'Reactions'),
(5242, 'english', 'reactions_label', 'Reactions'),
(5243, 'espanol', 'reactions_label', 'Reactions'),
(5244, 'icelandic', 'reactions_label', 'Reactions'),
(5245, 'indonesian', 'reactions_label', 'Reactions'),
(5246, 'jawa', 'reactions_label', 'Reactions'),
(5247, 'portuguese', 'reactions_label', 'Reactions'),
(5248, 'turkish', 'reactions_label', 'Reactions'),
(5249, 'deutsch', 'terms_developers_label', 'Developers'),
(5250, 'english', 'terms_developers_label', 'Developers'),
(5251, 'espanol', 'terms_developers_label', 'Developers'),
(5252, 'icelandic', 'terms_developers_label', 'Developers'),
(5253, 'indonesian', 'terms_developers_label', 'Developers'),
(5254, 'jawa', 'terms_developers_label', 'Developers'),
(5255, 'portuguese', 'terms_developers_label', 'Developers'),
(5256, 'turkish', 'terms_developers_label', 'Developers'),
(5257, 'deutsch', 'api_documentation_label', 'API Documentation'),
(5258, 'english', 'api_documentation_label', 'API Documentation'),
(5259, 'espanol', 'api_documentation_label', 'API Documentation'),
(5260, 'icelandic', 'api_documentation_label', 'API Documentation'),
(5261, 'indonesian', 'api_documentation_label', 'API Documentation'),
(5262, 'jawa', 'api_documentation_label', 'API Documentation'),
(5263, 'portuguese', 'api_documentation_label', 'API Documentation'),
(5264, 'turkish', 'api_documentation_label', 'API Documentation'),
(5775, 'deutsch', 'api_version_label', 'API Version'),
(5776, 'english', 'api_version_label', 'API Version'),
(5777, 'espanol', 'api_version_label', 'API Version'),
(5778, 'icelandic', 'api_version_label', 'API Version'),
(5779, 'indonesian', 'api_version_label', 'API Version'),
(5780, 'jawa', 'api_version_label', 'API Version'),
(5781, 'portuguese', 'api_version_label', 'API Version'),
(5782, 'turkish', 'api_version_label', 'API Version'),
(5783, 'deutsch', 'no_reactions_label', 'No reactions yet!'),
(5784, 'english', 'no_reactions_label', 'No reactions yet!'),
(5785, 'espanol', 'no_reactions_label', 'No reactions yet!'),
(5786, 'icelandic', 'no_reactions_label', 'No reactions yet!'),
(5787, 'indonesian', 'no_reactions_label', 'No reactions yet!'),
(5788, 'jawa', 'no_reactions_label', 'No reactions yet!'),
(5789, 'portuguese', 'no_reactions_label', 'No reactions yet!'),
(5790, 'turkish', 'no_reactions_label', 'No reactions yet!');